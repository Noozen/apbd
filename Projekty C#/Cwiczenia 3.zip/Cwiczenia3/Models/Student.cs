﻿namespace Cwiczenia3.Models
{
    public class Student
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string IndexNumber { get; set; }
    }
}
